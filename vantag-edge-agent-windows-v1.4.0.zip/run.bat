@echo off
REM Vantag Edge Agent launcher (Windows)
cd /d "%~dp0"
if not exist "requirements.txt" (
  echo.
  echo ============================================================
  echo   STOP - the files are still inside the ZIP.
  echo.
  echo   You double-clicked run.bat from inside the zip preview.
  echo   Please do this instead:
  echo     1^) Close this window
  echo     2^) Find vantag-edge-agent-windows.zip in your Downloads
  echo     3^) Right-click it and choose "Extract All..."
  echo     4^) Open the EXTRACTED folder
  echo     5^) Double-click run.bat there
  echo ============================================================
  echo.
  pause
  exit /b 1
)
where python >nul 2>nul || (echo Python 3.10+ is required. Install from python.org && pause && exit /b 1)
if not exist .venv (python -m venv .venv)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m agent.main
pause
