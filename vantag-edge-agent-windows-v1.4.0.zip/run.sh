#!/usr/bin/env bash
# Vantag Edge Agent launcher (Linux/macOS)
set -e
cd "$(dirname "$0")"
if [ ! -f requirements.txt ]; then
  echo "ERROR: requirements.txt not found. Did you extract the zip first?"
  echo "Run:  unzip vantag-edge-agent-linux.zip -d vantag-agent && cd vantag-agent && ./run.sh"
  exit 1
fi
command -v python3 >/dev/null 2>&1 || { echo "Python 3.10+ is required."; exit 1; }
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m agent.main
