"""
Per-camera RTSP worker thread.
Connects to an RTSP stream, runs YOLOv8 inference, and posts events to backend.

Analyzers implemented
---------------------
  shoplifting        – person near high-value item for >2s
  restricted_zone    – person stationary at same spot for >30s
  inventory_movement – no shelf item detected for >60s
  fall_detected      – person bounding-box aspect ratio transitions from tall→wide (h/w ≤ 0.75)
  loitering          – person in a coarse grid cell for >loiter_threshold_sec and still moving
"""
import base64
import collections
import logging
import threading
import time
from typing import Callable, Optional

import cv2
import numpy as np

from .config import CameraConfig
from .api_client import VantagApiClient
from .inference import YoloInference, RETAIL_CLASSES

log = logging.getLogger("vantag.camera")

# ---------------------------------------------------------------------------
# Fall Detector
# ---------------------------------------------------------------------------

class FallDetector:
    """
    Detects falls by tracking bounding-box aspect ratio transitions.

    A standing person has h/w >= STAND_RATIO.
    A fallen person has h/w <= FALL_RATIO.

    We track a rolling window of aspect ratios per coarse grid cell and emit
    'fall_detected' when the ratio transitions from standing to fallen.
    """

    STAND_RATIO = 1.10   # h/w threshold for "upright"
    FALL_RATIO  = 0.75   # h/w threshold for "fallen"
    HISTORY_LEN = 24     # frames (~9.6 s at 2.5 AI fps)

    def __init__(self, camera_id: str, cooldown_sec: int = 60):
        self.camera_id = camera_id
        self._cooldown = max(cooldown_sec, 60)
        # cell → deque of aspect ratios
        self._history: dict[str, collections.deque] = {}
        self._last_event: dict[str, float] = {}

    def _cell(self, p) -> str:
        """Coarse 4×4 grid cell key for a bounding box."""
        cx = int(min(p.x + p.w / 2, 0.999) * 4)
        cy = int(min(p.y + p.h / 2, 0.999) * 4)
        return f"{cx}_{cy}"

    def analyse(self, persons: list, frame: np.ndarray) -> Optional[dict]:
        now = time.time()
        for p in persons:
            ratio = p.h / p.w if p.w > 0 else 1.5
            cell = self._cell(p)
            dq = self._history.setdefault(cell, collections.deque(maxlen=self.HISTORY_LEN))
            dq.append(ratio)

            # Need at least half the window filled before judging
            if len(dq) < self.HISTORY_LEN // 2:
                continue

            prev_ratios = list(dq)[:-3]   # older portion
            recent_ratios = list(dq)[-3:]  # last 3 readings

            was_standing = any(r >= self.STAND_RATIO for r in prev_ratios)
            is_fallen    = all(r <= self.FALL_RATIO for r in recent_ratios)

            if was_standing and is_fallen:
                last = self._last_event.get(cell, 0)
                if now - last >= self._cooldown:
                    self._last_event[cell] = now
                    small = cv2.resize(frame, (320, 180))
                    _, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60])
                    snap = base64.b64encode(buf.tobytes()).decode()
                    return {
                        "camera_id": self.camera_id,
                        "event_type": "fall_detected",
                        "severity": "high",
                        "confidence": round(p.confidence, 3),
                        "snapshot_b64": snap,
                        "metadata": {
                            "timestamp": int(now * 1000),
                            "aspect_ratio": round(ratio, 3),
                            "bounding_boxes": [p.to_dict()],
                        },
                    }
        return None


# ---------------------------------------------------------------------------
# Loitering Detector
# ---------------------------------------------------------------------------

class LoiteringDetector:
    """
    Detects loitering: a person present in the same coarse grid zone for an
    extended period AND still moving (not simply standing still like dwell).

    Uses a 3×3 grid. Tracks per-cell presence start time and position variance.
    """

    MIN_PRESENCE_SEC = 90    # seconds in zone before alert
    MIN_MOVEMENT     = 0.06  # normalised position variance threshold

    def __init__(self, camera_id: str, cooldown_sec: int = 90):
        self.camera_id = camera_id
        self._cooldown = max(cooldown_sec, 90)
        # cell → {"first_seen": float, "positions": deque[(cx, cy)], "last_event": float}
        self._zones: dict[str, dict] = {}

    def _cell(self, p) -> str:
        cx = int(min(p.x + p.w / 2, 0.999) * 3)
        cy = int(min(p.y + p.h / 2, 0.999) * 3)
        return f"{cx}_{cy}"

    def analyse(self, persons: list, frame: np.ndarray) -> Optional[dict]:
        now = time.time()
        seen_cells: set[str] = set()

        for p in persons:
            cell = self._cell(p)
            seen_cells.add(cell)
            cx = p.x + p.w / 2
            cy = p.y + p.h / 2

            if cell not in self._zones:
                self._zones[cell] = {
                    "first_seen": now,
                    "positions": collections.deque(maxlen=50),
                    "last_event": 0.0,
                }
            zone = self._zones[cell]
            zone["positions"].append((cx, cy))

            dwell = now - zone["first_seen"]
            if dwell < self.MIN_PRESENCE_SEC:
                continue

            # Check movement variance
            positions = list(zone["positions"])
            if len(positions) < 5:
                continue
            xs = [pos[0] for pos in positions]
            ys = [pos[1] for pos in positions]
            variance = (max(xs) - min(xs)) + (max(ys) - min(ys))
            if variance <= self.MIN_MOVEMENT:
                continue  # standing still — handled by restricted_zone

            last = zone["last_event"]
            if now - last >= self._cooldown:
                zone["last_event"] = now
                small = cv2.resize(frame, (320, 180))
                _, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60])
                snap = base64.b64encode(buf.tobytes()).decode()
                return {
                    "camera_id": self.camera_id,
                    "event_type": "loitering",
                    "severity": "low",
                    "confidence": round(min(dwell / (self.MIN_PRESENCE_SEC * 2), 0.95), 3),
                    "snapshot_b64": snap,
                    "metadata": {
                        "timestamp": int(now * 1000),
                        "dwell_seconds": round(dwell, 1),
                        "movement_variance": round(variance, 4),
                        "bounding_boxes": [p.to_dict()],
                    },
                }

        # Expire zones where no person was seen this frame
        for cell in list(self._zones.keys()):
            if cell not in seen_cells:
                del self._zones[cell]

        return None


# ---------------------------------------------------------------------------
# Crowd Detector
# ---------------------------------------------------------------------------

class CrowdDetector:
    """
    Detects crowding: person count stays at/above a threshold for a sustained
    window. Uses a rolling count history so a single noisy frame doesn't fire.

    Emits 'crowding' (canonical backend type).
    """

    MIN_PERSONS   = 5     # >= this many people = potential crowd
    SUSTAIN_SEC   = 5.0   # must hold for this long before firing

    def __init__(self, camera_id: str, cooldown_sec: int = 60, min_persons: int = MIN_PERSONS):
        self.camera_id = camera_id
        self._cooldown = max(cooldown_sec, 60)
        self._min_persons = min_persons
        self._crowd_since: Optional[float] = None
        self._last_event: float = 0.0

    def analyse(self, persons: list, frame: np.ndarray) -> Optional[dict]:
        now = time.time()
        count = len(persons)

        if count >= self._min_persons:
            if self._crowd_since is None:
                self._crowd_since = now
            elif now - self._crowd_since >= self.SUSTAIN_SEC:
                if now - self._last_event >= self._cooldown:
                    self._last_event = now
                    small = cv2.resize(frame, (320, 180))
                    _, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60])
                    snap = base64.b64encode(buf.tobytes()).decode()
                    # Confidence scales with how far over the threshold we are
                    conf = min(0.5 + 0.1 * (count - self._min_persons), 0.95)
                    return {
                        "camera_id": self.camera_id,
                        "event_type": "crowding",
                        "severity": "high" if count >= self._min_persons * 2 else "medium",
                        "confidence": round(conf, 3),
                        "snapshot_b64": snap,
                        "metadata": {
                            "timestamp": int(now * 1000),
                            "person_count": count,
                            "threshold": self._min_persons,
                            "bounding_boxes": [p.to_dict() for p in persons],
                        },
                    }
        else:
            self._crowd_since = None

        return None


# ---------------------------------------------------------------------------
# Suspicious Behavior Detector
# ---------------------------------------------------------------------------

class SuspiciousBehaviorDetector:
    """
    Detects suspicious behavior via erratic movement: a person who repeatedly
    reverses horizontal direction (pacing / casing an area) within a coarse
    grid cell. Distinct from loitering (slow drift) and dwell (stationary).

    Emits 'suspicious_behavior' (canonical backend type).
    """

    HISTORY_LEN      = 20    # rolling window of centre-x positions per cell
    MIN_REVERSALS    = 4     # direction changes within the window to flag
    MIN_AMPLITUDE    = 0.04  # each swing must span at least this (normalised)

    def __init__(self, camera_id: str, cooldown_sec: int = 60):
        self.camera_id = camera_id
        self._cooldown = max(cooldown_sec, 60)
        self._tracks: dict[str, collections.deque] = {}
        self._last_event: dict[str, float] = {}

    def _cell(self, p) -> str:
        cx = int(min(p.x + p.w / 2, 0.999) * 4)
        cy = int(min(p.y + p.h / 2, 0.999) * 4)
        return f"{cx}_{cy}"

    def analyse(self, persons: list, frame: np.ndarray) -> Optional[dict]:
        now = time.time()
        seen: set[str] = set()

        for p in persons:
            cell = self._cell(p)
            seen.add(cell)
            cx = p.x + p.w / 2
            dq = self._tracks.setdefault(cell, collections.deque(maxlen=self.HISTORY_LEN))
            dq.append(cx)

            if len(dq) < self.HISTORY_LEN:
                continue

            reversals = self._count_reversals(list(dq))
            if reversals >= self.MIN_REVERSALS:
                last = self._last_event.get(cell, 0)
                if now - last >= self._cooldown:
                    self._last_event[cell] = now
                    small = cv2.resize(frame, (320, 180))
                    _, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60])
                    snap = base64.b64encode(buf.tobytes()).decode()
                    return {
                        "camera_id": self.camera_id,
                        "event_type": "suspicious_behavior",
                        "severity": "medium",
                        "confidence": round(min(0.5 + 0.1 * reversals, 0.95), 3),
                        "snapshot_b64": snap,
                        "metadata": {
                            "timestamp": int(now * 1000),
                            "direction_reversals": reversals,
                            "bounding_boxes": [p.to_dict()],
                        },
                    }

        # Drop tracks for cells with no person this frame
        for cell in list(self._tracks.keys()):
            if cell not in seen:
                del self._tracks[cell]
                self._last_event.pop(cell, None)

        return None

    def _count_reversals(self, xs: list) -> int:
        """Count significant horizontal direction changes in a position series."""
        reversals = 0
        direction = 0          # -1 left, +1 right, 0 unknown
        anchor = xs[0]
        for x in xs[1:]:
            delta = x - anchor
            if abs(delta) < self.MIN_AMPLITUDE:
                continue
            new_dir = 1 if delta > 0 else -1
            if direction != 0 and new_dir != direction:
                reversals += 1
            direction = new_dir
            anchor = x
        return reversals


# ---------------------------------------------------------------------------
# Detection Analyzer (orchestrates all sub-detectors)
# ---------------------------------------------------------------------------

class DetectionAnalyzer:
    """
    Orchestrates per-frame detection results and decides when to emit events.

    Events emitted (canonical backend types):
      shoplifting         – person near high-value item for >2s
      restricted_zone     – person stationary in sensitive zone for >30s
      inventory_movement  – no shelf item for >60s
      fall_detected       – aspect-ratio transition standing→fallen
      loitering           – person in zone >90s while still moving
      crowding            – person count >= threshold sustained for >5s
      suspicious_behavior – person pacing / reversing direction in a zone
    """

    _SEVERITY_MAP = {
        "shoplifting":         "high",
        "restricted_zone":     "medium",
        "inventory_movement":  "medium",
        "fall_detected":       "high",
        "loitering":           "low",
        "crowding":            "medium",
        "suspicious_behavior": "medium",
    }

    def __init__(self, camera_id: str, cooldown_sec: int = 30, fps: float = 5.0):
        self.camera_id = camera_id
        self.cooldown_sec = cooldown_sec
        self.fps = fps
        self._last_event: dict[str, float] = {}
        self._person_with_items: dict[str, float] = {}
        self._person_frame_counts: dict[str, int] = {}
        self._shelf_empty_since: Optional[float] = None

        self._fall_detector = FallDetector(camera_id, cooldown_sec)
        self._loiter_detector = LoiteringDetector(camera_id, cooldown_sec)
        self._crowd_detector = CrowdDetector(camera_id, cooldown_sec)
        self._suspicious_detector = SuspiciousBehaviorDetector(camera_id, cooldown_sec)

    def _can_emit(self, event_type: str) -> bool:
        last = self._last_event.get(event_type, 0)
        return (time.time() - last) >= self.cooldown_sec

    def _emit(self, event_type: str, confidence: float, boxes: list, frame: np.ndarray) -> Optional[dict]:
        if not self._can_emit(event_type):
            return None
        self._last_event[event_type] = time.time()
        small = cv2.resize(frame, (320, 180))
        _, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60])
        snap = base64.b64encode(buf.tobytes()).decode()
        severity = self._SEVERITY_MAP.get(event_type, "medium")
        if confidence >= 0.85 and severity == "medium":
            severity = "high"
        return {
            "camera_id": self.camera_id,
            "event_type": event_type,
            "severity": severity,
            "confidence": round(confidence, 3),
            "snapshot_b64": snap,
            "metadata": {
                "timestamp": int(time.time() * 1000),
                "bounding_boxes": [b.to_dict() for b in boxes],
            },
        }

    def analyse(self, boxes: list, frame: np.ndarray) -> list[dict]:
        """Given a list of BoundingBox, return list of events to emit."""
        events = []
        now = time.time()

        persons     = [b for b in boxes if b.label == "person"]
        items       = [b for b in boxes if RETAIL_CLASSES.get(b.label) == "high_value_item"]
        shelf_items = [b for b in boxes if RETAIL_CLASSES.get(b.label) == "shelf_item"]

        # 1. Shoplifting: person near high-value item for >2s
        # Key on the ITEM's position (items are stationary — backpack/bag on shelf).
        # Keying on the person would reset the timer whenever they walk a grid cell
        # width (~64px at 640p) before the 2s window closes.
        if persons and items:
            for p in persons:
                for item in items:
                    if self._boxes_overlap(p, item, threshold=0.3):
                        key = f"sweep_{int(item.x*10)}_{int(item.y*10)}"
                        self._person_with_items.setdefault(key, now)
                        if now - self._person_with_items[key] >= 2.0:
                            evt = self._emit("shoplifting", max(p.confidence, item.confidence), [p, item], frame)
                            if evt:
                                events.append(evt)
            # Prune item slots where no person has been nearby for >30s
            stale = [k for k, t in self._person_with_items.items() if now - t > 30]
            for k in stale:
                del self._person_with_items[k]
        else:
            self._person_with_items.clear()

        # 2. Restricted Zone: person stationary for >30s
        for p in persons:
            key = f"dwell_{int(p.x * 100)}_{int(p.y * 100)}"
            self._person_frame_counts[key] = self._person_frame_counts.get(key, 0) + 1
            frames_needed = int(30 * self.fps)
            if self._person_frame_counts[key] >= frames_needed:
                evt = self._emit("restricted_zone", p.confidence, [p], frame)
                if evt:
                    events.append(evt)
                self._person_frame_counts[key] = 0

        # Clean up stale dwell counters
        if len(self._person_frame_counts) > 20:
            oldest = sorted(self._person_frame_counts, key=lambda k: self._person_frame_counts[k])[:10]
            for k in oldest:
                del self._person_frame_counts[k]

        # 3. Inventory Movement: no shelf items for >60s
        if not shelf_items:
            if self._shelf_empty_since is None:
                self._shelf_empty_since = now
            elif now - self._shelf_empty_since >= 60.0:
                evt = self._emit("inventory_movement", 0.85, [], frame)
                if evt:
                    events.append(evt)
        else:
            self._shelf_empty_since = None

        # 4. Fall Detection
        fall_evt = self._fall_detector.analyse(persons, frame)
        if fall_evt:
            events.append(fall_evt)

        # 5. Loitering
        loiter_evt = self._loiter_detector.analyse(persons, frame)
        if loiter_evt:
            events.append(loiter_evt)

        # 6. Crowding
        crowd_evt = self._crowd_detector.analyse(persons, frame)
        if crowd_evt:
            events.append(crowd_evt)

        # 7. Suspicious behavior (pacing / direction reversals)
        suspicious_evt = self._suspicious_detector.analyse(persons, frame)
        if suspicious_evt:
            events.append(suspicious_evt)

        return events

    @staticmethod
    def _boxes_overlap(a, b, threshold: float = 0.3) -> bool:
        x_overlap = max(0, min(a.x + a.w, b.x + b.w) - max(a.x, b.x))
        y_overlap = max(0, min(a.y + a.h, b.y + b.h) - max(a.y, b.y))
        overlap_area = x_overlap * y_overlap
        min_area = min(a.w * a.h, b.w * b.h)
        return overlap_area >= threshold * min_area if min_area > 0 else False


# ---------------------------------------------------------------------------
# Camera Worker
# ---------------------------------------------------------------------------

class CameraWorker:
    # Give up after this many consecutive connection failures so cameras with
    # no real RTSP stream (e.g. demo placeholders) don't flood the log forever.
    MAX_FAILURES = 3

    def __init__(
        self,
        config: CameraConfig,
        inference: YoloInference,
        api_client: VantagApiClient,
        conf_threshold: float = 0.6,
        target_fps: int = 5,
        event_cooldown_sec: int = 30,
        on_event: Optional[Callable[[dict], None]] = None,
    ):
        self.config = config
        self._inference = inference
        self._api = api_client
        self._conf = conf_threshold
        self._target_fps = target_fps
        self._on_event = on_event
        self._analyzer = DetectionAnalyzer(
            camera_id=config.id,
            cooldown_sec=event_cooldown_sec,
            fps=float(target_fps),
        )

        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.current_fps: float = 0.0
        self.is_connected: bool = False
        self.error_msg: str = ""
        self.consecutive_failures: int = 0
        self._last_preview_t: float = 0.0

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name=f"cam-{self.config.id}",
            daemon=True,
        )
        self._thread.start()
        log.info(f"[{self.config.name}] Worker started → {self.config.rtsp_url}")

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        log.info(f"[{self.config.name}] Worker stopped")

    def _run(self):
        frame_interval = 1.0 / self._target_fps
        inference_every = 2   # run AI every 2nd captured frame

        # Guard: the backend must hand us a real rtsp:// URL. If it still looks
        # encrypted ("fernet:") or isn't an rtsp/http URL, the cloud server
        # failed to decrypt it (old build or wrong VANTAG_ENCRYPTION_KEY).
        # Surface a single, human-readable error instead of hammering FFmpeg
        # with an undecryptable blob.
        _url = (self.config.rtsp_url or "").strip()
        if _url.startswith("fernet:") or not _url.lower().startswith(("rtsp://", "http://", "https://")):
            self.is_connected = False
            self.error_msg = (
                "Camera URL was not decrypted by the server. Re-save this camera "
                "in Manage Cameras, and make sure the backend is updated."
            )
            log.error(f"[{self.config.name}] {self.error_msg} (got: {_url[:24]}...)")
            return

        while not self._stop_event.is_set():
            cap = None
            try:
                cap = cv2.VideoCapture(self.config.rtsp_url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

                if not cap.isOpened():
                    raise ConnectionError(f"Cannot open RTSP stream: {self.config.rtsp_url}")

                self.is_connected = True
                self.consecutive_failures = 0
                self.error_msg = ""
                log.info(f"[{self.config.name}] RTSP connected")

                # Force a live-preview push on the very first decoded frame after
                # every (re)connect. Flaky NVR streams can drop within ~9s, before
                # the 10s periodic timer ever fires, so without this the cloud
                # dashboard would never receive a single still.
                self._last_preview_t = 0.0

                frame_count = 0
                fps_t0 = time.time()
                fps_frames = 0

                while not self._stop_event.is_set():
                    t_start = time.time()
                    ret, frame = cap.read()
                    if not ret:
                        raise ConnectionError("Frame read failed — stream ended")

                    frame_count += 1
                    fps_frames += 1

                    elapsed = time.time() - fps_t0
                    if elapsed >= 2.0:
                        self.current_fps = fps_frames / elapsed
                        fps_frames = 0
                        fps_t0 = time.time()

                    if frame_count % inference_every == 0:
                        boxes = self._inference.detect(frame, conf_threshold=self._conf)
                        events = self._analyzer.analyse(boxes, frame)
                        for event in events:
                            log.info(
                                f"[{self.config.name}] Event: {event['event_type']} "
                                f"conf={event['confidence']} sev={event['severity']}"
                            )
                            if self._on_event:
                                self._on_event(event)
                            self._api.post_event(event)

                    # Periodic live-preview push (~every 10s) so the cloud
                    # dashboard can show a near-real-time still even though the
                    # RTSP stream never leaves the local network.
                    if time.time() - self._last_preview_t >= 10.0:
                        self._last_preview_t = time.time()
                        try:
                            h, w = frame.shape[:2]
                            scale = 640.0 / max(w, 1)
                            if scale < 1.0:
                                small = cv2.resize(frame, (int(w * scale), int(h * scale)))
                            else:
                                small = frame
                            ok, buf = cv2.imencode(
                                ".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 60]
                            )
                            if ok:
                                b64 = base64.b64encode(buf.tobytes()).decode("ascii")
                                self._api.post_preview(self.config.id, b64)
                        except Exception:  # noqa: BLE001
                            pass

                    sleep_time = frame_interval - (time.time() - t_start)
                    if sleep_time > 0:
                        time.sleep(sleep_time)

            except Exception as e:
                self.is_connected = False
                self.consecutive_failures += 1
                self.error_msg = str(e)
                log.warning(f"[{self.config.name}] Error: {e} (failures={self.consecutive_failures})")
                if self.consecutive_failures >= self.MAX_FAILURES:
                    log.error(
                        f"[{self.config.name}] Giving up after {self.MAX_FAILURES} "
                        f"consecutive failures — no valid RTSP stream. Worker stopping."
                    )
                    break
                backoff = min(2 ** self.consecutive_failures, 60)
                log.info(f"[{self.config.name}] Reconnecting in {backoff}s...")
                self._stop_event.wait(timeout=backoff)
            finally:
                if cap:
                    cap.release()
