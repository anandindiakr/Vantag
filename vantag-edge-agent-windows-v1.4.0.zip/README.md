# Vantag Edge Agent - SETUP INSTRUCTIONS

############################################################
#  STEP 1 (IMPORTANT): EXTRACT THIS ZIP FIRST              #
#  Do NOT run run.bat from inside the zip preview window.  #
#  Right-click the downloaded .zip -> "Extract All..."     #
#  then open the extracted folder before continuing.       #
############################################################

This package is pre-configured for YOUR account (your keys are already inside
config.json - keep it private).

## What this does
It runs on a PC that is on the SAME local network (LAN) as your cameras. It
connects OUT to the Vantag cloud, so your cameras never need to be exposed to
the internet. This is why cameras on your LAN cannot be tested directly from
the website - the Edge Agent is what reaches them.

## Requirements
- A Windows or Linux PC kept switched on, on the same network as the cameras
- Python 3.10 or newer (Windows: install from https://python.org and tick
  "Add Python to PATH" during install)

## Windows - how to run
1. Extract the zip (see STEP 1 above).
2. Open the extracted folder.
3. Double-click `run.bat`.
   The first run downloads dependencies (a few minutes) and then starts.
4. Leave the window open. Your cameras turn ONLINE in the dashboard in ~30s.

## Linux / Raspberry Pi - how to run
    unzip vantag-edge-agent-linux.zip -d vantag-agent
    cd vantag-agent
    chmod +x run.sh
    ./run.sh

## After it starts
- Cameras appear ONLINE in your dashboard within ~30 seconds.
- Use "Auto-Scan with Edge Agent" on the Manage Cameras page to discover
  cameras on your LAN automatically.
- Real AI detections show on the Incidents page with snapshot evidence.

## Need help?
Email support@retailnazar.com (India) / support@retail-vantag.com, or use the
"Need help setting up?" chat in the app.
